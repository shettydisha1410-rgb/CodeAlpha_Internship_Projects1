# CodeAlpha - FAQ Chatbot

A chatbot built with Python and Streamlit that answers frequently asked questions.

## How it works
- The user types a question
- The text is cleaned using NLTK (lowercase, remove common words, shorten words)
- TF-IDF and cosine similarity (written in plain Python) find the most similar FAQ
- The matching answer is shown in a chat window

## How to run
pip install -r requirements.txt
streamlit run chatbot.py

## Tech used
Python, Streamlit, NLTK
import math
import re
from collections import Counter

import nltk
import streamlit as st
from nltk.stem import PorterStemmer

# ---------------- 0. NLTK stopwords (common words like "the", "is") ----------------
try:
    from nltk.corpus import stopwords

    nltk.download("stopwords", quiet=True)
    STOP = set(stopwords.words("english"))
except Exception:
    STOP = {"i", "me", "my", "we", "you", "your", "is", "are", "was", "the", "a", "an",
            "and", "or", "of", "to", "in", "on", "do", "does", "how", "what", "can",
            "it", "this", "that", "for", "with", "at", "by", "from", "be", "there"}

# ---------------- 1. FAQ data: (question, answer, extra keywords) ----------------
# Keywords are other words people may use for the same question.
FAQS = [
    ("How can I track my order?",
     "Go to 'My Orders' and click 'Track'. You will also get a tracking link by email once your order ships.",
     "where package parcel shipment status location"),
    ("What is your return policy?",
     "You can return any item within 30 days of delivery if it is unused and in its original packaging.",
     "send back exchange replace item"),
    ("How long does shipping take?",
     "Standard shipping takes 3-7 business days. Express shipping takes 1-2 business days.",
     "delivery arrive days when soon deliver"),
    ("What payment methods do you accept?",
     "We accept credit/debit cards, UPI, net banking, wallets, and cash on delivery.",
     "pay card upi cod cash online"),
    ("How do I cancel my order?",
     "You can cancel from 'My Orders' before the order is shipped. After that, please request a return instead.",
     "cancel stop remove"),
    ("How do I get a refund?",
     "Refunds go to your original payment method within 5-7 business days after we receive the returned item.",
     "money back refund reimburse"),
    ("Do you ship internationally?",
     "Yes, we ship to over 50 countries. International delivery takes 7-14 business days.",
     "abroad overseas worldwide outside country deliver international foreign"),
    ("How can I contact customer support?",
     "Email support@example.com or call 1800-123-456, Monday to Saturday, 9 AM to 6 PM.",
     "phone call email help support reach number"),
    ("Can I change my delivery address?",
     "Yes, you can change the address from 'My Orders' before the order is shipped.",
     "address change update edit location deliver"),
    ("How do I reset my password?",
     "Click 'Forgot password' on the login page and follow the link sent to your registered email.",
     "password forgot login account sign"),
]

# ---------------- 2. Clean the text (NLTK) ----------------
stemmer = PorterStemmer()


def preprocess(text):
    tokens = re.findall(r"[a-z0-9]+", text.lower())               # split into words
    return [stemmer.stem(t) for t in tokens if t not in STOP]      # remove common words, shorten words


# ---------------- 3. TF-IDF (word importance), written by hand ----------------
docs = [preprocess(q + " " + k) for q, _, k in FAQS]
N = len(docs)

df = Counter()                       # in how many FAQs does each word appear?
for d in docs:
    df.update(set(d))
idf = {w: math.log((1 + N) / (1 + c)) + 1 for w, c in df.items()}   # rare words get higher score


def vectorize(tokens):
    tf = Counter(tokens)
    vec = {w: c * idf[w] for w, c in tf.items() if w in idf}
    norm = math.sqrt(sum(v * v for v in vec.values()))
    return {w: v / norm for w, v in vec.items()} if norm else {}


doc_vecs = [vectorize(d) for d in docs]


# ---------------- 4. Cosine similarity (how close two sentences are) ----------------
def cosine(a, b):
    return sum(v * b.get(w, 0.0) for w, v in a.items())


THRESHOLD = 0.15  # below this score, the bot says it does not know


def get_answer(user_question):
    q_vec = vectorize(preprocess(user_question))
    if not q_vec:
        return "Sorry, I could not understand that. Please ask about orders, shipping, returns or payments."
    scores = [cosine(q_vec, d) for d in doc_vecs]
    best = max(range(N), key=lambda i: scores[i])
    if scores[best] < THRESHOLD:
        return "Sorry, I could not find an answer to that. Please contact support@example.com."
    return FAQS[best][1]


# ---------------- 5. Chat screen ----------------
st.set_page_config(page_title="FAQ Chatbot", page_icon="🤖")
st.title("🤖 FAQ Chatbot")
st.caption("Ask me about orders, shipping, returns, payments and more.")

if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "assistant", "content": "Hi! How can I help you today?"}]

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.write(m["content"])

if prompt := st.chat_input("Type your question..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.write(prompt)
    reply = get_answer(prompt)
    st.session_state.messages.append({"role": "assistant", "content": reply})
    with st.chat_message("assistant"):
        st.write(reply)
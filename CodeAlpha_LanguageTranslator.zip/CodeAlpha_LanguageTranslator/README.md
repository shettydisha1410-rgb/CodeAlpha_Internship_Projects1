# CodeAlpha - Language Translation Tool

A web app built with Python and Streamlit that translates text between many languages.

## Features
- Choose source and target languages
- Translation using Google Translate (with MyMemory as a fallback)
- Pronunciation shown in English letters
- Copy button and text-to-speech

## How to run
pip install -r requirements.txt
streamlit run app.py

## Tech used
Python, Streamlit, deep-translator, gTTS
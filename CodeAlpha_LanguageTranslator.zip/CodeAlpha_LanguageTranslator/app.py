import io
import time

import requests
import streamlit as st
from deep_translator import GoogleTranslator, MyMemoryTranslator
from gtts import gTTS
from unidecode import unidecode

st.set_page_config(page_title="Language Translator", page_icon="🌐")
st.title("🌐 Language Translation Tool")

LANGS = GoogleTranslator().get_supported_languages(as_dict=True)
names = sorted(LANGS.keys())

col1, col2 = st.columns(2)
with col1:
    src_name = st.selectbox("Source language", names, index=names.index("english"))
with col2:
    tgt_name = st.selectbox("Target language", names, index=names.index("hindi"))

text = st.text_area("Enter text to translate", height=150)


def translate_with_romanization(text, src, tgt):
    """Returns (translated_text, romanized_text_or_None) using Google's web endpoint."""
    url = "https://translate.googleapis.com/translate_a/single"
    params = {
        "client": "gtx",
        "sl": src,
        "tl": tgt,
        "dt": ["t", "rm"],  # t = translation, rm = romanization (English letters)
        "q": text,
    }
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    data = r.json()

    translated = ""
    roman = None
    for seg in data[0]:
        if seg[0]:                                   # normal translated chunk
            translated += seg[0]
        elif len(seg) > 2 and isinstance(seg[2], str):  # romanization chunk
            roman = seg[2]
    return translated, roman


def translate_text(text, src_name, tgt_name):
    src = LANGS[src_name]
    tgt = LANGS[tgt_name]

    # 1) Google with romanization
    for attempt in range(2):
        try:
            translated, roman = translate_with_romanization(text, src, tgt)
            if translated:
                return translated, roman, "Google Translate"
        except Exception:
            time.sleep(1.5)

    # 2) Fallback: MyMemory (romanization via unidecode)
    try:
        translated = MyMemoryTranslator(source=src_name, target=tgt_name).translate(text)
        return translated, None, "MyMemory"
    except Exception as e:
        raise RuntimeError(f"Both services failed. Last error: {e}")


if st.button("Translate", type="primary"):
    if not text.strip():
        st.warning("Please enter some text.")
    else:
        try:
            with st.spinner("Translating..."):
                result, roman, engine = translate_text(text, src_name, tgt_name)
            st.session_state["result"] = result
            st.session_state["roman"] = roman
            st.session_state["tgt_code"] = LANGS[tgt_name]
            st.session_state["engine"] = engine
        except Exception as e:
            st.error(f"Translation failed: {e}")

if "result" in st.session_state:
    result = st.session_state["result"]
    st.subheader("Translated text")
    st.code(result, language=None)  # has a built-in copy button

    # English-letter version in brackets
    roman = st.session_state.get("roman")
    if not roman:
        roman = unidecode(result).strip()  # backup if Google gave no romanization
    if roman and roman.lower() != result.lower():
        st.markdown(f"**In English letters:** ({roman})")

    st.caption(f"Translated using {st.session_state['engine']}")

    if st.button("🔊 Speak translation"):
        try:
            audio = io.BytesIO()
            gTTS(result, lang=st.session_state["tgt_code"]).write_to_fp(audio)
            st.audio(audio.getvalue(), format="audio/mp3")
        except Exception as e:
            st.error(f"Text-to-speech not available for this language: {e}")